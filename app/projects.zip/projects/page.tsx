import React from "react";
import { allProjects } from "contentlayer/generated";
import { Navigation } from "../components/nav";
import { Card } from "../components/card";
import { Article } from "./article";

export default async function ProjectsPage() {
  // Fetch and sort projects by date
  const sorted = allProjects
    .filter((p) => p.published)
    .sort((a, b) => new Date(b.date ?? 0).getTime() - new Date(a.date ?? 0).getTime());

  // Set Cyber Dodge as the featured project
  const featured = sorted.find((p) => p.slug === "cyber-dodge") || sorted[0];
  const remaining = sorted.filter((p) => p.slug !== featured?.slug);

  return (
    <div className="relative pb-16">
      <Navigation />
      <div className="px-6 pt-20 mx-auto space-y-8 max-w-7xl lg:px-8 md:pt-32">
        <div className="max-w-2xl mx-auto lg:mx-0">
          <h2 className="text-3xl font-bold tracking-tight text-zinc-100 sm:text-4xl">
            Projects
          </h2>
          <p className="mt-4 text-zinc-400">
            Robotics, AI, and Security experiments by Alpha-02.
          </p>
        </div>
        <div className="w-full h-px bg-zinc-800" />
        
        {featured && (
          <Card>
            <Article project={featured} views={0} />
          </Card>
        )}

        <div className="grid grid-cols-1 gap-4 mx-auto lg:grid-cols-3">
          {remaining.map((project) => (
            <Card key={project.slug}>
              <Article project={project} views={0} />
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}